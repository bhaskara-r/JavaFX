/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package fxmltableview;

import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author kamalanathanr
 */
public class CyclehistoryData {
    private final SimpleStringProperty CycleNumber = new SimpleStringProperty("");
   private final SimpleStringProperty Status = new SimpleStringProperty("");
   private final SimpleStringProperty CompDateTime = new SimpleStringProperty("");
   private final SimpleStringProperty reason  = new SimpleStringProperty("");

public CyclehistoryData() {
        this("", "", "","");
    }
 
    public CyclehistoryData(String firstName, String lastName, String email, String Reason) {
        setCycleNumber(firstName);
        setStatus(lastName);
        setCompDateTime(email);
        setReason(Reason);
    }

    public String getCycleNumber() {
        return CycleNumber.get();
    }
 
    public void setCycleNumber(String fName) {
        CycleNumber.set(fName);
    }
        
    public String getStatus() {
        return Status.get();
    }
    
    public void setStatus(String fName) {
        Status.set(fName);
    }
    
    public String getCompDateTime() {
        return CompDateTime.get();
    }
    
    public void setCompDateTime(String fName) {
        CompDateTime.set(fName);
    }
    
    public String getReason() {
        return reason.get();
    }
    
    public void setReason(String Reason) {
        reason.set(Reason);
    }
}
