/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessLayer;

/**
 *
 * @author raja
 */
public class UIScreenID {
    public static final int SPLASH_SCREEN = 1;
    public static final int OPERATOR_LOGIN_SCREEN = 2;
    public static final int PM1_DUE_SCREEN = 3;
    public static final int PM1_PAST_DUE_SCREEN = 4;
    public static final int PM2_DUE_SCREEN = 5;
    public static final int PM2_PAST_DUE_SCREEN = 6;
    public static final int ENTER_LOAD_ITEM_DATA_SCREEN = 7;
    public static final int CYCLE_NOTES_SCREEN = 8;
    public static final int SELECT_CYCLE_SCREEN = 9;
    public static final int CYCLE_HISTORY_SCREEN = 10;
    public static final int UTILITIES_SCREEN = 11;
    public static final int SYSTEM_CONFIGURATION =12;
public static final int START_CYCLE_SCREEN = 13;
    
    
    public static final int END_OF_SCREEN = 12;
    
    
        
}
