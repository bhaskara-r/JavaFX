/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessLayer;

/**
 *
 * @author raja
 */
public class UIEventID {
    /*Splash screen*/
    public static final int SPLASH_SCREEN_TOUCH_VALID_EVENT = 1;  /* used for touch event in any screen */
    public static final int SPLASH_SCREEN_MOUSE_CLICK = 2;     /* mouse event in Splash Screen */
    public static final int SPLASH_SCREEN_DONE_BUTTON_PRESS = 3;
//    public static final int
    /*Select Cycle Screen event Id*/
    public static final int SELECT_CYCLE_BACK_BUTTON_PRESS=4;
    public static final int SELECT_CYCLE_STANDARD_BUTTON_PRESS =5;
    public static final int SELECT_CYCLE_FLEX_BUTTON_PRESS =6;
    public static final int SELECT_CYCLE_DUO_BUTTON_PRESS =7;
    public static final int SELECT_CYCLE_EXPRESS_BUTTON_PRESS =8;
    public static final int SELECT_CYCLE_STANDARD_INFO_BUTTON_PRESS =9;
    public static final int SELECT_CYCLE_FLEX_INFO_BUTTON_PRESS =10;
    public static final int SELECT_CYCLE_DUO_INFO_BUTTON_PRESS =11;
    public static final int SELECT_CYCLE_EXPRESS_INFO_BUTTON_PRESS =12;
    public static final int SELECT_CYCLE_LOGOUT_BUTTON_PRESS =13;
    public static final int SELECT_CYCLE_HISTORY_INFO_BUTTON_PRESS =14;
    public static final int SELECT_CYCLE_UTLITIES_BUTTON_PRESS =15;
    public static final int SELECT_CYCLE_OPENDOOR_BUTTON_PRESS =16;
    
    /*Utilities screen*/
    public static final int UTILITIES_SYS_CONFIG_BUTTON_PRESS =17;
    public static final int UTILITIES_BACK_BUTTON_PRESS=18;
    //UPTO 30 FOR UTILITES SCREEN EVENT ID,SO NEXT EVENT FOR SCREEN SHLD START WITH 31
    
    /*CycleHistory Screen*/
    public static final int CYCLE_HISTORY_BACK_BUTTON_PRESS=32;
    //upto36 for Cycle History event id, so next event shld start from 37
    
    /*Start Cycle screen*/
    public static final int START_CYCLE_CANCEL_BUTTON_PRESS = 38;
    public static final int START_CYCLE_START_BUTTON_PRESS = 39;
    public static final int START_CYCLE_OPENDOOR_BUTTON_PRESS = 40;
    
    
    
    
}
