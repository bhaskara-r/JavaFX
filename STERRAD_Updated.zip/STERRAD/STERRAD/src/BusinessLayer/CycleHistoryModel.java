/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BusinessLayer;

/**
 *
 * @author kamalanathanr
 */
public class CycleHistoryModel {
     private static CycleHistoryModel instance;
     
     private CycleHistoryModel(){};
     
      public static CycleHistoryModel getInstance(){
        if(instance == null){
            instance = new CycleHistoryModel();
        }
        return instance;
    }
    
}
