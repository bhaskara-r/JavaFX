/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessLayer;

/**
 *
 * @author indhumathi-ss
 */
public class GUIConstants {
    
    public static final String std_cycle="STANDARD Cycle";
    public static final String duo_cycle="DUO Cycle";
    public static final String  flex_cycle ="FLEX Cycle";
    public static final String express_cycle="EXPRESS Cycle";
    
    
    //Additional Utilities
    public static final String additionalUtilities_lblTitle = "additionalUtilities.title";
    public static final String additionalUtilities_lblDateandTime = "additionalUtilities.dateAndTime";
    public static final String additionalUtilities_lblSysConfig = "additionalUtilities.systemConfig";
    public static final String additionalUtilities_lblUserAdmin = "additionalUtilities.userAdmin";
    public static final String additionalUtilities_lblDisposeCassette = "additionalUtilities.disposeCassette";
    public static final String additionalUtilities_lblNetwork = "additionalUtilities.network";
    public static final String additionalUtilities_lblSelfDiag = "commonLabels.selfDiagnostics";
    public static final String additionalUtilities_lblServiceFunc = "additionalUtilities.serviceFunctions";
    public static final String additionalUtilities_lblFileManagement = "additionalUtilities.fileManagement";
    public static final String additionalUtilities_lblUploadFile = "additionalUtilities.uploadFile";
    public static final String additionalUtilities_lblIDoorOpen = "additionalUtilities.inputDoorOpen";
    public static final String additionalUtilities_lblIDoorClose = "additionalUtilities.inputDoorClose";
    public static final String additionalUtilities_lblODoorOpen = "additionalUtilities.outputDoorOpen";
    public static final String additionalUtilities_lblODoorClose =  "additionalUtilities.outputDoorClose";
    public static final String additionalUtilities_lblProductOptions = "additionalUtilities.productOptions";	
    
    //System Config
    public static final String systemConfig_lbltitle = "systemConfig.title";
    public static final String systemConfig_lblAccessControl1 = "systemConfig.accessControl1";
    public static final String systemConfig_lblAccessControl2 = "systemConfig.loadRemovalOption2";
    public static final String systemConfig_lblUserLogin = "systemConfig.userLogin";
    public static final String systemConfig_lblNoUserLogin = "systemConfig.noUserLogin";
    public static final String systemConfig_lblPrintoutOption = "systemConfig.printOption";
    public static final String systemConfig_lblShortFormat = "systemConfig.shortFormat";
    public static final String systemConfig_lblLoginFormat = "systemConfig.longFormat";
    public static final String systemConfig_lblDoorOption = "SystemSummary.Entry81";
    public static final String systemConfig_lblSingleDoor = "systemConfig.singleDoor";
    public static final String systemConfig_lblDoubleDoor = "systemConfig.doubleDoor";
    public static final String systemConfig_lblVacuumUnits = "SystemSummary.Entry14";
    public static final String systemConfig_lblTorr = "systemConfig.torr";
    public static final String systemConfig_lblKPa = "systemConfig.KPa";
    public static final String systemConfig_lblLoadDataEntryOption1 = "systemConfig.loadDataEntryOption1";
    //public static final String systemConfig_lblLoadDataEntryOption2 = "systemConfig.loadDataEntryOption2";
    public static final String systemConfig_lblEnabled = "SystemSummary.Entry60";
    public static final String systemConfig_lblDisabled = "SystemSummary.Entry61";
    public static final String systemConfig_lblLoadRemovalOption1 = "systemConfig.loadRemovalOption1";
    //public static final String systemConfig_lblLoadRemovalOption2 = "systemConfig.loadRemovalOption2";
    public static final String systemConfig_lblWithLogin = "systemConfig.withLogin";
    public static final String systemConfig_lblWithoutLogin = "systemConfig.withoutLogin";
    public static final String systemConfig_lblNotepadOption = "systemConfig.notepadOption";
    public static final String systemConfig_lblAlarmVol1 = "systemConfig.alarmVol1";
    public static final String systemConfig_lblAlarmVol2 = "systemConfig.alarmVol2";
    public static final String systemConfig_lblMin = "systemConfig.min";
    public static final String systemConfig_lblMax = "systemConfig.max";
    public static final String systemConfig_lblSoundVol1= "systemConfig.soundVol1";
    public static final String systemConfig_lblSoundVol2= "systemConfig.soundVol2";
    public static final String systemConfig_lblBacklight1 = "systemConfig.backlight1";
    public static final String systemConfig_lblBacklight2= "systemConfig.backlight2";
    public static final String systemConfig_lblBacklight3= "systemConfig.backlight3";
    public static final String systemConfig_networkOption1 = "systemConfig.networkOption1";
   
   //Backlight minutes
    public static final String systemConfig_lblBacklight15 = "systemConfig.backlight15";
    public static final String systemConfig_lblBacklight30 = "systemConfig.backlight30";
    public static final String systemConfig_lblBacklight60 = "systemConfig.backlight60";
    
    public static final String systemConfig_lblLanguageSel1 = "systemConfig.languageSel1";
    public static final String systemConfig_lblLanguageSel2 = "systemConfig.languageSel2";
    public static final String systemConfig_lblIMS = "systemConfig.lblIMS";
    public static final String systemConfig_lblprintersel1 = "systemConfig.printersel1";
    public static final String systemConfig_lblprintersel2 = "systemConfig.printersel2";
    public static final String systemConfig_lblInternalPrinter = "systemConfig.InternalPrinter";
    public static final String systemConfig_lblInternalip = "systemConfig.Internalip";
    public static final String systemConfig_lblInternalop = "systemConfig.Internalop";
    public static final String systemConfig_lblExternal = "systemConfig.External"; 
    public static final String systemConfig_lblSterilizerId = "systemConfig.lblSterilizerId";
    public static final String systemConfig_lblBiNotification = "systemConfig.biNotification";
    public static final String systemConfig_lblEnable = "systemConfig.enabled";
    public static final String systemConfig_lblDisable = "systemConfig.disabled";
    public static final String systemConfig_lblApollo = "systemConfig.lblApollo";
    public static final String systemconfig1_sterilizer ="systemconfig1.sterilizer";
    public static final String systemConfig_lblPrintNetOption = "systemConfig.lblPrintNetOption";
    public static final String systemConfig_lblTransferOption = "systemConfig.lblTransferOption";
    
    
   // public static final String systemConfig_lblDept = "SystemSummary.Entry21";
   // public static final String systemConfig_lblFacilityName = "SystemSummary.Entry20";
    //public static final String systemConfig_lblSterilizerID = "SystemSummary.Entry22";
    //public static final String systemConfig_lblSterilizerSerial = "systemConfig.sterilizerSerial";

    //Cycle Graph
    public static final String commonLabels_CycleGraph = "commonLabels.CycleGraph";
    public static final String commonLabels_PrintLong  = "commonLabels.PrintLong";
    public static final String commonLabels_PrintShort = "commonLabels.PrintShort";
    public static final String commonLabels_PrintCycle = "commonLabels.PrintCycle";
    public static final String commonLabels_lblZoom = "commonLabels.lblZoom";
    public static final String commonLabels_lblZoomSettings="commonLabels.lblZoomSettings";
    public static final String commonLabels_lblLoadDefault="commonLabels.default";

    //Cycle History Screen
    public static final String CycleHistory_lblHeaderTitle= "CycleHistory.lblHeaderTitle";
    public static final String CycleHistory_lblPrintList= "CycleHistory.lblPrintList";
    public static final String CycleHistory_lblViewCycle= "CycleHistory.lblViewCycle";
    public static final String CycleHistory_lblPrintShort= "CycleHistory.lblPrintShort";
    public static final String CycleHistory_lblPrintLong= "CycleHistory.lblPrintLong";

    public static final String CycleHistory_ColumnCycleNo="CycleHistory.ColumnCycleNo";
    public static final String CycleHistory_ColumnStatus="diagnosticsTemperature.status";
    public static final String CycleHistory_ColumnDataNTime="CycleHistory.ColumnDataNTime";
    public static final String CycleHistory_ColumnReason="CycleHistory.ColumnReason";
    public static final String CycleMenu_Title = "CycleMenu.Title";
    
    
    public static final String singleCycleStartCycle_lblTitle = "singleCycleStartCycle.title";
    //Start Cycle screen
    public static final String startCycle_cycleBITitle= "startCycle.cycleBITitle";
    public static final String startCycle_cycleOnly= "startCycle.cycleOnly";
    public static final String startCycle_inputFileName_StandardCycle = "startCycle.inputFileName.StandardCycle";
    public static final String startCycle_inputFileName_FlexCycle="startCycle.inputFileName.Flex";
    public static final String startCycle_inputFileName_DuoCycle = "startCycle.inputFileName.DuoCycle";
    public static final String startCycle_inputFileNameExpress = "startCycle.inputFileName.Express";
    public static final String CycleStartPanel_cycle = "cycleStartPanel.cycle";
    public static final String standard_cycle_Info_lbl="startCycle.standard_cycle_Info";
    public static final String duo_cycle_Info_lbl="startCycle.duo_cycle_Info";
    public static final String express_cycle_Info_lbl="startCycle.express_cycle_Info";
    public static final String flex_cycle_Info_lbl="startCycle.flex_cycle_Info";
    
    //Splash
    public static final String Splash_lblLeftText = "Splash.lblLeftText";
    public static final String Splash_lblRightText = "Splash.lblRightText";
    public static final String Splash_lblSubTitle = "Splash.lblSubTitle";
   
    //Cycle start confirmation screen
    public static final String cycleStart_lblStdCycle = "cycleStart.lblStdCycle";
    public static final String cycleStart_lblFlexCycle = "cycleStart.lblFlexCycle";
    public static final String cycleStart_lblExpressCycle = "cycleStart.lblExpressCycle";
    public static final String cycleStart_lblDuoCycle = "cycleStart.lblDuoCycle";
    public static final String cycleStart_lblStdDescription ="cycleStart.lblStdDescription";
    public static final String cycleStart_lblFlexDescription ="cycleStart.lblFlexDescription";
    public static final String cycleStart_lblExpressDescription ="cycleStart.lblExpressDescription";
    public static final String cycleStart_lblDuoDescription ="cycleStart.lblDuoDescription";
    public static final String cycleStart_lblStdLoadMsg ="cycleStart.lblStdLoadMsg";
    public static final String cycleStart_lblFlexLoadMsg ="cycleStart.lblFlexLoadMsg";
    public static final String cycleStart_lblExpressLoadMsg ="cycleStart.lblExpressLoadMsg";
    public static final String cycleStart_lblDuoLoadMsg1 ="cycleStart.lblDuoLoadMsg1";
    public static final String cycleStart_lblDuoLoadMsg2 ="cycleStart.lblDuoLoadMsg2";
    public static final String cycleStart_lblFootNote = "cyleStart.lblFootNote";
    public static final String cycleStart_lblBiInfoMsg = "cycleStart.lblBiInfoMsg";
    public static final String commonLabels_lblOR = "commonLabels.lblOR";
    public static final String singleCycleStartCycle_lblStartCycle = "singleCycleStartCycle.subTitle2";
    


    // Common Label
    public static final String commonLabels_lblSTART= "commonLabels.start";
    public static final String commonLabels_lblMins = "commonLabels.lblMins";
    public static final String commonLabels_lblLogout = "commonLabels.logout";
    public static final String commonLabels_lblBack = "commonLabels.back";
    public static final String commonLabels_lblCycleHistory = "commonLabels.cycleHistory";
    public static final String commonLabels_lblAdditionUtilities = "commonLabels.additionalUtilities";
    public static final String commonLabels_done = "commonLabels.done";
    public static final String commonLabels_lblCancel = "commonLabels.cancel";
    public static final String commonLabels_lblMinutes = "commonLabels.lblMinutes";
    
    // Cycle Info
    public static final String expressCycleConfirm_Msg="startCycle.standardCycleConfirm_Msg";
    public static final String StdDescription       = "CycleInfo.StandardDescription";
    public static final String StdInstrument        = "CycleInfo.StandardInstrument";
    public static final String DuoDescription       = "CycleInfo.DUODescription";
    public static final String DuoInstrument        = "CycleInfo.DUOInstrument";
    public static final String FlxDescription       = "CycleInfo.FlexDescription";
    public static final String FlxInstrument        = "CycleInfo.FlexInstrument";
    public static final String ExpDescription       = "CycleInfo.ExpressDescription";
    public static final String ExpInstrument        = "CycleInfo.ExpressInstrument";
    public static final String CycleInfo_headerTitle = "CycleInfo.headerTitle";
    
    public static int CycleName=0;
    
}
