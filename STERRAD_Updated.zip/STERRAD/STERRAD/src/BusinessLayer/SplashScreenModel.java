/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessLayer;

/**
 *
 * @author raja
 */
public class SplashScreenModel {
    
    private static SplashScreenModel instance;
    public String partNo;
    
    private SplashScreenModel() {};
    
    public static SplashScreenModel getInstance(){
        if(instance == null){
            instance = new SplashScreenModel();
        }
        return instance;
    }

    public String getPartNo() {
        return partNo;
    }

    public void setPartNo(String partNo) {
        this.partNo = partNo;
    }

  
    
    
}
