/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sterrad;

/**
 *
 * @author raja
 */
public class UIFXMLFileConstants {
    
   
    /**
     *
     */
    
    public static final String SPLASH_SCREEN_FXML_FILE = "customer/SplashScreen.fxml";
    public static final String OPERATOR_LOGIN_FXML_FILE = "OperatorLogin.fxml";
    public static final String SYSTEM_CONFIGURATION_FXML_FILE = "customer/SystemConfiguration.fxml";
    public static final String SELECT_CYCLE_FXML_FILE = "customer/SelectCycle.fxml";
    public static final String CYCLE_HISTORY_FXML_FILE = "customer/CycleHistory.fxml";
    public static final String UTLITIES_FXML_FILE="customer/AdditionalUtilities.fxml";
    public static final String START_CYCLE_FXML_FILE="customer/StartCycle.fxml";
    
    public static final String PM1_DUE_FXML_FILE = "PMDue.fxml";
    public static final String PM1_PAST_DUE_FXML_FILE = "PMPastDue.fxml";
    public static final String PM2_DUE_FXML_FILE = "PMDue.fxml";
    public static final String PM2_PAST_DUE_FXML_FILE = "PMPastDue.fxml";
    public static final String ENTER_LOAD_ITEM_KB_FXML_FILE = "EnterLoadItemDataFromKB.fxml";
    public static final String ENTER_LOAD_ITEM_LIST_FXML_FILE = "EnterLoadItemDataFromList.fxml";    
    public static final String CYCLE_NOTES_FXML_FILE = "CyclesNotes.fxml";    
   // public static final String UTILITIES_FXML_FILE = "AdditionalUtilities.fxml";
    public static final String DUMMYFXML="FooterPanel4Btn.fxml";
    
}
