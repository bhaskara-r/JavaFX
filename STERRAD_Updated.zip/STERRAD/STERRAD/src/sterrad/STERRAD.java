/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sterrad;


import BusinessLayer.TempClass;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import static sterrad.UIFXMLFileConstants.*;
import static BusinessLayer.UIScreenID.*;
import javafx.scene.Group;

/**
 *
 * @author raja
 */
public class STERRAD extends Application {
    STRStackPane strStackPane = new STRStackPane();
    TempClass tmpClass = new TempClass();
    
    
    
    @Override
    public void start(Stage stage) throws Exception {
    
        tmpClass.initModelData();
        
        LoadSTRStackPane();
         boolean setScreen = strStackPane.setScreen(SPLASH_SCREEN);
         //strStackPane.setScreen(UTILITIES_SCREEN);
        
        Group root = new Group();
        root.getChildren().addAll(strStackPane);
        
        Scene scene = new Scene(root);
        stage.setScene(scene);        
        stage.show();
     }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    private void LoadSTRStackPane() {
         boolean loadScreen;
        strStackPane.loadScreen(SPLASH_SCREEN, SPLASH_SCREEN_FXML_FILE);
        strStackPane.loadScreen(SELECT_CYCLE_SCREEN,SELECT_CYCLE_FXML_FILE);
        strStackPane.loadScreen(CYCLE_HISTORY_SCREEN,CYCLE_HISTORY_FXML_FILE);
        strStackPane.loadScreen(SYSTEM_CONFIGURATION,SYSTEM_CONFIGURATION_FXML_FILE);
        strStackPane.loadScreen(UTILITIES_SCREEN,UTLITIES_FXML_FILE);
        strStackPane.loadScreen(START_CYCLE_SCREEN,START_CYCLE_FXML_FILE);
    }
    
}
