/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sterrad;

import static BusinessLayer.UIEventID.*;
import static BusinessLayer.UIScreenID.*;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 *
 * @author rajesh kamalanathan
 */
public class UIBaseClass {
     ResourceBundle labels = ResourceBundle.getBundle("resources/langbundle/labelsBundle", new Locale("en","US"));
    protected STRStackPane SceneHandler;//it holds the present screen corresponding to the event ID.
    
    public void ProcessKeyEvent(int eventID) {
        System.out.println(eventID);
        
        switch(eventID){
    /*Splash Screen*/
    case(SPLASH_SCREEN_TOUCH_VALID_EVENT):
    case(SPLASH_SCREEN_MOUSE_CLICK):
    case(SPLASH_SCREEN_DONE_BUTTON_PRESS ) : SceneHandler.setScreen(SELECT_CYCLE_SCREEN); break;

    /*Select Cycle Screen event Id*/
    case(SELECT_CYCLE_BACK_BUTTON_PRESS) : break;
    case(SELECT_CYCLE_STANDARD_BUTTON_PRESS ) :
    case(SELECT_CYCLE_FLEX_BUTTON_PRESS) :
    case(SELECT_CYCLE_DUO_BUTTON_PRESS) :
    case(SELECT_CYCLE_EXPRESS_BUTTON_PRESS ) :
         SceneHandler.setScreen(START_CYCLE_SCREEN);
        break;
    case(SELECT_CYCLE_STANDARD_INFO_BUTTON_PRESS ) : break;
    case(SELECT_CYCLE_FLEX_INFO_BUTTON_PRESS) : break;
    case(SELECT_CYCLE_DUO_INFO_BUTTON_PRESS) : break;
    case(SELECT_CYCLE_EXPRESS_INFO_BUTTON_PRESS) :  break;
    case(SELECT_CYCLE_LOGOUT_BUTTON_PRESS) : break;
    case(SELECT_CYCLE_HISTORY_INFO_BUTTON_PRESS) :
        System.out.println("Click CycleHistory");
        SceneHandler.setScreen(CYCLE_HISTORY_SCREEN);
        break;
    case(SELECT_CYCLE_UTLITIES_BUTTON_PRESS) :
        SceneHandler.setScreen(UTILITIES_SCREEN);
        break;
    case(SELECT_CYCLE_OPENDOOR_BUTTON_PRESS) : break;
    
    
    /*utlities screen*/
    case(UTILITIES_SYS_CONFIG_BUTTON_PRESS) :
        SceneHandler.setScreen(SYSTEM_CONFIGURATION);
        break;
      case(UTILITIES_BACK_BUTTON_PRESS) :
        SceneHandler.setScreen(SELECT_CYCLE_SCREEN);
        break;
     /*Cycle History screen*/   
    case(CYCLE_HISTORY_BACK_BUTTON_PRESS) :
        SceneHandler.setScreen(SELECT_CYCLE_SCREEN);
        break;
     /*Start Cycle*/
         case(START_CYCLE_CANCEL_BUTTON_PRESS) :
        SceneHandler.setScreen(SELECT_CYCLE_SCREEN); 
        
    default:
        System.out.println(eventID);
        }
        
    }
    
    public String getKeyValue(String key)
    {
        String value  = null;
        value  = labels.getString(key);
        return value;
    } 
    
    
}
