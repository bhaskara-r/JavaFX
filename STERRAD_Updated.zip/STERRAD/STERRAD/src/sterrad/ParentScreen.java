/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sterrad;

/**
 *
 * @author raja
 */
public interface ParentScreen {
    
     
    public void setParentScreen(STRStackPane screenPage);//,STRStackPane PrevPage);
    
   
    public void initDisplay();
    
    public void updateDisplayData();
    
   
    
}