/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sterrad.customer;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import BusinessLayer.SplashScreenModel;
import static BusinessLayer.UIEventID.*;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import sterrad.ParentScreen;
import sterrad.STRStackPane;
import sterrad.UIBaseClass;
import javafx.fxml.FXMLLoader;

/**
 * FXML Controller class
 *
 * @author indhumathi-ss
 */
public class AdditionalUtilitiesController extends UIBaseClass implements Initializable, ParentScreen {

    STRStackPane myPage;
    SplashScreenModel screenModelData;
    @FXML
    private Pane UtilitiesPane;
    @FXML
    private Button btnDateTime;
    @FXML
    private Button btnSysConfig;
    @FXML
    private Button btnUserAdmin;
    @FXML
    private Button btnCassetteFunctions;
    @FXML
    private Button btnNetwork;
    @FXML
    private Button btnSelfDiag;
    @FXML
    private Button btnServiceFunctions;
    @FXML
    private Button btnFileManagement;
    @FXML
    private Button btnUploadFile;
    @FXML
    private Button btnIDoorOpen;
    @FXML
    private Button btnIDoorClose;
    @FXML
    private Button btnODoorOpen;
    @FXML
    private Button btnODoorClose;
    @FXML
    private Button btnProductOptions;
    @FXML
    private Label lblHeaderTitle;
    @FXML
    private Label lblDate;
    @FXML
    private Label lblTime;
    @FXML
    private Label BackArrow;
    @FXML
    private Button Back;
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        //screenModelData = SplashScreenModel.getInstance();
    }    
    
    @Override
    public void setParentScreen(STRStackPane screenPage) {
        myPage = screenPage;
        SceneHandler = myPage;
    }

    @Override
    public void initDisplay() {
       
    Timeline timeline;
    timeline = new Timeline(
              new KeyFrame(Duration.seconds(0),
                      new EventHandler<javafx.event.ActionEvent>() {
             @Override
             public void handle(javafx.event.ActionEvent event) {
                 lblTime.setText(gettime());
                 lblDate.setText(getdate());
                }}
              ),
              new KeyFrame(Duration.seconds(1))
      );
    timeline.setCycleCount(Animation.INDEFINITE);
    timeline.play();
    BackArrow.setText("\u25C4");
    
 }
    
   public String getdate()          
  {
    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    Date date = new Date();
    //System.out.println(dateFormat.format(date)); 
    return dateFormat.format(date);
  }
  public String gettime()          
  {
    DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss a");
    Date date = new Date();
   // System.out.println(dateFormat.format(date));
    
    return dateFormat.format(date);
  }
           

    @Override
    public void updateDisplayData() {
      // setTitle("Additional Utilitites Menu") ;
    }

 public void setTitle(String strTitle) {
        lblHeaderTitle.setText(strTitle);
    }

    @FXML
    private void handleMouseClick(MouseEvent event) {
        
        if(event.getSource()==  btnSysConfig)  ProcessKeyEvent(UTILITIES_SYS_CONFIG_BUTTON_PRESS);
        else if(event.getSource()==  Back)  ProcessKeyEvent(UTILITIES_BACK_BUTTON_PRESS);
        
    }

    
}
