/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sterrad.customer;


import BusinessLayer.GUIConstants;
import static BusinessLayer.UIEventID.*;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;
import sterrad.ParentScreen;
import sterrad.STRStackPane;
import sterrad.UIBaseClass;

/**
 *
 * @author bhaskara-r
 */
public class SelectCycleController extends UIBaseClass implements Initializable, ParentScreen {
    
    
    STRStackPane myPage;    
    Stage prevStage;    
    private Label label;
    
    @FXML
    private Label LabelBack;
    @FXML
    private AnchorPane HoldingPane;
    @FXML
    private Label SystemReady;
    @FXML
    private Label Time;
    @FXML
    private Label Date;
    @FXML
    private Button Logout;
    @FXML
    private Button CycleHistory;
    @FXML
    private Button Utilities;
    @FXML
    private Button OpenClose;
    
    @FXML
    private Button BackButton;
    @FXML
    private Button StandardCycle;
    @FXML
    private Button FlexCycle;
    @FXML
    private Button DuoCycle;
    @FXML
    private Button ExpressCycle;
    @FXML
    private Button StandardInfo;
    @FXML
    private Button FlexInfo;
    @FXML
    private Button DuoInfo;
    @FXML
    private Button ExpressInfo;

    public void setPrevStage(Stage stage){
         this.prevStage = stage;
    }
    
    
    public void gotoCreateCategory(ActionEvent event) throws IOException {
       Stage stage = new Stage();
       stage.setTitle("Shop Management");
       Pane myPane = null;
       myPane = FXMLLoader.load(getClass().getResource("Footer.fxml"));
       Scene scene = new Scene(myPane);
       stage.setScene(scene);

       prevStage.close();

       stage.show();
    }
    
     public void handleButtonAction(ActionEvent event) throws IOException {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
        gotoCreateCategory(event);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        LabelBack.setText("\u25C4");
        Timeline timeline;
        timeline = new Timeline(
              new KeyFrame(Duration.seconds(0),
                      new EventHandler<javafx.event.ActionEvent>() {
             @Override
             public void handle(javafx.event.ActionEvent event) {
                 Time.setText(gettime());
                 Date.setText(getdate());
                }}
              ),
              new KeyFrame(Duration.seconds(1))
          );
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
      
        
    }   
    
    public String getdate()          
    {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
     //   System.out.println(dateFormat.format(date)); 
        return dateFormat.format(date);
    }
    public String gettime()          
    {
        DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss a");
        Date date = new Date();
       // System.out.println(dateFormat.format(date));
    
        return dateFormat.format(date);
    }


    @Override
    public void setParentScreen(STRStackPane screenPage) {
         myPage = screenPage;
          SceneHandler = myPage;
         
//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void initDisplay() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updateDisplayData() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @FXML
    private void handleMouseClick(MouseEvent event) {
   
   if(event.getSource()== BackButton)       
       ProcessKeyEvent(SELECT_CYCLE_BACK_BUTTON_PRESS);
   
      
   else if(event.getSource()==  Logout)  ProcessKeyEvent(SELECT_CYCLE_LOGOUT_BUTTON_PRESS);
    
   else if(event.getSource()==  CycleHistory)  ProcessKeyEvent(SELECT_CYCLE_HISTORY_INFO_BUTTON_PRESS);
    
   else if(event.getSource()==  Utilities)  ProcessKeyEvent(SELECT_CYCLE_UTLITIES_BUTTON_PRESS);
    
   else if(event.getSource()==  OpenClose)  ProcessKeyEvent(SELECT_CYCLE_OPENDOOR_BUTTON_PRESS);
    
   else if(event.getSource()==  StandardCycle){GUIConstants.CycleName=1;  ProcessKeyEvent(SELECT_CYCLE_STANDARD_BUTTON_PRESS);}
    
   else if(event.getSource()==  FlexCycle){GUIConstants.CycleName=2;  ProcessKeyEvent(SELECT_CYCLE_FLEX_BUTTON_PRESS);}
    
   else if(event.getSource()==  DuoCycle){GUIConstants.CycleName=3;  ProcessKeyEvent(SELECT_CYCLE_DUO_BUTTON_PRESS);}
    
   else if(event.getSource()==  ExpressCycle){GUIConstants.CycleName=4;  ProcessKeyEvent(SELECT_CYCLE_EXPRESS_BUTTON_PRESS);}
    
   else if(event.getSource()==  StandardInfo)  ProcessKeyEvent(SELECT_CYCLE_STANDARD_INFO_BUTTON_PRESS);
    
   else if(event.getSource()==  FlexInfo)  ProcessKeyEvent(SELECT_CYCLE_FLEX_INFO_BUTTON_PRESS);
    
   else if(event.getSource()==  DuoInfo)  ProcessKeyEvent(SELECT_CYCLE_DUO_INFO_BUTTON_PRESS);
    
    else if(event.getSource()==   ExpressInfo)  ProcessKeyEvent(SELECT_CYCLE_EXPRESS_INFO_BUTTON_PRESS);
    }

   
    
    
    
}
/*@FXML
    private Button Logout;
    @FXML
    private Button CycleHistory;
    @FXML
    private Button Utilities;
    @FXML
    private Button OpenClose;
    
    @FXML
    private Button BackButton;
    @FXML
    private Button StandardCycle;
    @FXML
    private Button FlexCycle;
    @FXML
    private Button DuoCycle;
    @FXML
    private Button ExpressCycle;
    @FXML
    private Button StandardInfo;
    @FXML
    private Button FlexInfo;
    @FXML
    private Button DuoInfo;
    @FXML
    private Button ExpressInfo;*/