/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sterrad.customer;

import BusinessLayer.GUIConstants;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import static BusinessLayer.UIEventID.*;
import sterrad.ParentScreen;
import sterrad.STRStackPane;
import sterrad.UIBaseClass;

/**
 * FXML Controller class
 *
 * @author kamalanathanr
 */
public class StartCycle_Controller extends UIBaseClass implements Initializable, ParentScreen {
    STRStackPane myPage;
    
    @FXML
    private ImageView imgShelf;
    @FXML
    private Pane linePanel;
    @FXML
    private Label lblCylceName;
    @FXML
    private Label lblCycleInfo;
    @FXML
    private Label lblInfo;
    @FXML
    private ImageView imgArrow;
    @FXML
    private Label lblArrowmessage;
    @FXML
    private Label lblNotes;
    @FXML
    private ImageView imgArrow1;
    @FXML
    private Label lblArrowmessage1;
    @FXML
    private ImageView imgRight;
    @FXML
    private ImageView imgLeft;
    @FXML
    private Label lblleft;
    @FXML
    private Label lblRight;
    @FXML
    private Label lblOr;
    @FXML
    private Label SystemReady;
    @FXML
    private Label Time;
    @FXML
    private Label Date;
    @FXML
    private Button OpenClose;
    @FXML
    private Button Cancel;
    
    //SelectCycleScreenModel screenModelData;
  
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    // Set Time & Date
    SetTimeDate();
        
    //screenModelData = SelectCycleScreenModel.getInstance();
    //SelectCycleType(screenModelData.GetCurrentCycle());
    
    setduo(false);
    lblCylceName.setText(getKeyValue(GUIConstants.cycleStart_lblStdCycle));
    lblCycleInfo.setText(getKeyValue(GUIConstants.cycleStart_lblStdDescription));
    lblInfo.setText(getKeyValue(GUIConstants.cycleStart_lblStdLoadMsg));
    
    
    }   
    
    public void SetTimeDate() {
        
        Timeline timeline;
        timeline = new Timeline(
           new KeyFrame(Duration.seconds(0),
           new EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
                 Time.setText(gettime());
                 Date.setText(getdate());
                }}
              ),
            new KeyFrame(Duration.seconds(1))
          );
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
    }
    
     public String getdate()          
    {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        System.out.println(dateFormat.format(date)); 
        return dateFormat.format(date);
    }
    public String gettime()          
    {
        DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss a");
        Date date = new Date();
        System.out.println(dateFormat.format(date));
    
        return dateFormat.format(date);
    }
  
      @Override
    public void setParentScreen(STRStackPane screenPage) {
        myPage = screenPage;
        SceneHandler = myPage;
    }

    @Override
    public void initDisplay() {
        switch(GUIConstants.CycleName)
        {
            case 1://standard
            setduo(false);
            lblCylceName.setText(getKeyValue(GUIConstants.cycleStart_lblStdCycle));
            lblCycleInfo.setText(getKeyValue(GUIConstants.cycleStart_lblStdDescription));
            lblInfo.setText(getKeyValue(GUIConstants.cycleStart_lblStdLoadMsg));
            break;
            
            case 2: //flex
            setduo(false);
            lblCylceName.setText(getKeyValue(GUIConstants.cycleStart_lblFlexCycle));
            lblCycleInfo.setText(getKeyValue(GUIConstants.cycleStart_lblFlexDescription));
            lblInfo.setText(getKeyValue(GUIConstants.cycleStart_lblFlexLoadMsg));
            break;
            
            case 3://duo
            setduo(true);
            lblCylceName.setText(getKeyValue(GUIConstants.cycleStart_lblDuoCycle));
            lblCycleInfo.setText(getKeyValue(GUIConstants.cycleStart_lblDuoDescription));
            break;
            case 4://express
            setduo(false);
            lblCylceName.setText(getKeyValue(GUIConstants.cycleStart_lblExpressCycle));
            lblCycleInfo.setText(getKeyValue(GUIConstants.cycleStart_lblExpressDescription));
            lblInfo.setText(getKeyValue(GUIConstants.cycleStart_lblExpressLoadMsg));
            break;
            default:
                GUIConstants.CycleName=0;
                       
        }
        
    }

    @Override
    public void updateDisplayData() {
        
    }
    
    
    @FXML
    private void changeme(MouseEvent event) {
        if(lblCylceName.getText().equals(GUIConstants.std_cycle))
        {
            setduo(false);
          
            lblCylceName.setText(getKeyValue(GUIConstants.cycleStart_lblFlexCycle));
            lblCycleInfo.setText(getKeyValue(GUIConstants.cycleStart_lblFlexDescription));
            lblInfo.setText(getKeyValue(GUIConstants.cycleStart_lblFlexLoadMsg));
        }
        else if(lblCylceName.getText().equals(GUIConstants.flex_cycle))
        {
            setduo(false);
            lblCylceName.setText(getKeyValue(GUIConstants.cycleStart_lblExpressCycle));
            lblCycleInfo.setText(getKeyValue(GUIConstants.cycleStart_lblExpressDescription));
            lblInfo.setText(getKeyValue(GUIConstants.cycleStart_lblExpressLoadMsg));
        }
        else if(lblCylceName.getText().equals(GUIConstants.express_cycle))
        {
            setduo(true);
           lblCylceName.setText(getKeyValue(GUIConstants.cycleStart_lblDuoCycle));
           lblCycleInfo.setText(getKeyValue(GUIConstants.cycleStart_lblDuoDescription));

        }
        else if(lblCylceName.getText().equals(GUIConstants.duo_cycle))
        {
            setduo(false);
            lblCylceName.setText(getKeyValue(GUIConstants.cycleStart_lblStdCycle));
            lblCycleInfo.setText(getKeyValue(GUIConstants.cycleStart_lblStdDescription));
            lblInfo.setText(getKeyValue(GUIConstants.cycleStart_lblStdLoadMsg));
        }       
        
}
    

    
    private void setduo(boolean visible)            
    {


if(visible)
{
lblleft.setVisible(true);
lblRight.setVisible(true);
lblOr.setVisible(true);
imgLeft.setVisible(true);
imgRight.setVisible(true);
lblArrowmessage1.setVisible(true);
imgArrow1.setVisible(true);

//lblCycleInfo.setVisible(false);
imgArrow.setVisible(false);
lblArrowmessage.setVisible(false);
imgShelf.setVisible(false);
lblInfo.setVisible(false);
}

  else
{
//lblCycleInfo.setVisible(true);
imgArrow.setVisible(true);
lblArrowmessage.setVisible(true);
imgShelf.setVisible(true);
lblInfo.setVisible(true);

lblleft.setVisible(false);
lblOr.setVisible(false);
lblRight.setVisible(false);
imgLeft.setVisible(false);
imgRight.setVisible(false);
lblArrowmessage1.setVisible(false);
imgArrow1.setVisible(false);
}
    }

    private void Cancel_clicked(MouseEvent event) {
        ProcessKeyEvent(START_CYCLE_CANCEL_BUTTON_PRESS);
    }

    @FXML
    private void Start_Cycle_clicked(MouseEvent event) {
        ProcessKeyEvent(START_CYCLE_START_BUTTON_PRESS);
    }

    @FXML
    private void Door_Open_Clicked(MouseEvent event) {
        ProcessKeyEvent(START_CYCLE_OPENDOOR_BUTTON_PRESS);
    }

    @FXML
    private void handleMouseClick(MouseEvent event) {
        if(event.getSource()==  Cancel)  ProcessKeyEvent(START_CYCLE_CANCEL_BUTTON_PRESS);
    }


}
