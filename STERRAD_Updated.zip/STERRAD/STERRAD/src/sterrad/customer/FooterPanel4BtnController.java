/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sterrad.customer;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

/**
 * FXML Controller class
 *
 * @author raja
 */
public class FooterPanel4BtnController implements Initializable {

    
    @FXML
    private void handleLogoutButtonAction(ActionEvent event) {
        
    }
    
    @FXML
    private void handleCycleHistoryButtonAction(ActionEvent event) {
        
    }
    
     @FXML
    private void handleUtilitiesButtonAction(ActionEvent event) {
        
    }
    
     @FXML
    private void handleDoorButtonAction(ActionEvent event) {
        
    }
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
