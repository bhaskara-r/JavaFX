/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sterrad.customer;

import java.awt.event.ActionEvent;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

/**
 * FXML Controller class
 *
 * @author raja
 */
public class HeaderPanelController implements Initializable {

    @FXML
    private Label lblHeaderTitle;
    
    @FXML
    private Label lblDate;
    
    @FXML
    private Label lblTime;
    
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      
    }
    
    @FXML
    private void OnPanelClick(ActionEvent Event) {
      
        
    // System.out.println(btnLogout.getParent().lookup("Logoutclick"));  
     // ProcessNavigation(LogoutButton);
     
   //  Event mouseEvent = new MouseEvent();
     
 //    MouseEvent();
 /*    Event.fireEvent(btnCycleHistory, new MouseEvent(MouseEvent.MOUSE_CLICKED, 0,
                    0, 0, 0, MouseButton.PRIMARY, 1, true, true, true, true,
                    true, true, true, true, true, true, null)); */
 
    Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Delete " + "selection" + " ?", ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
    alert.showAndWait();
     
     // KeyEvent press = new KeyEvent(backspace, textField, KeyEvent.KEY_PRESSED, "", "", KeyCode.BACK_SPACE, false, false, false, false);
     // textField.fireEvent(press);
            
    }
  
    
    
    
    public void setTitle(String strTitle) {
        lblHeaderTitle.setText(strTitle);
    }
    
   
}
