/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sterrad.customer;

import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import sterrad.ParentScreen;
import sterrad.STRStackPane;
import sterrad.UIBaseClass;

/**
 *
 * @author hadoop
 */
public class SystemConfiguration_Controller extends UIBaseClass implements Initializable, ParentScreen  {
     STRStackPane myPage;
     Stage prevStage;
     
    private Label label;
    @FXML
    private RadioButton UserLogin;
    @FXML
    private RadioButton NoUserLogin;
    @FXML
    private RadioButton VaccTorr;
    @FXML
    private RadioButton ImsEnabled;
    @FXML
    private RadioButton ImsDisabled;
    @FXML
    private RadioButton VaccKpa;
    @FXML
    private RadioButton LoadEnabled;
    @FXML
    private RadioButton LoadDisabled;
    @FXML
    private RadioButton LoadRemEnabled;
    @FXML
    private RadioButton LoadRemDisabled;
    @FXML
    private RadioButton NotepadDisabled;
    @FXML
    private RadioButton NotepadEnabled;
    @FXML
    private RadioButton AutoSendEnabled;
    @FXML
    private RadioButton AutoSendDisabled;
    @FXML
    private RadioButton BINotifyEnabled;
    @FXML
    private RadioButton BINotifyDisabled;
    @FXML
    private Label lblHeaderTitle;
 
    @FXML
    private Label SystemReady;
    @FXML
    private Label Time;
    @FXML
    private Label Date;
    @FXML
    private ProgressBar ProgressBar;
    @FXML
    private Label lblDate;
    @FXML
    private Label lblTime;
    
    
       public void setPrevStage(Stage stage){
         this.prevStage = stage;
    }
       
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        SystemReady.setText("System Configuration");
        // Grouping of Radio Buttons
            ToggleGroup group1 = new ToggleGroup();
            ToggleGroup group2 = new ToggleGroup();
            ToggleGroup group3 = new ToggleGroup();
            ToggleGroup group4 = new ToggleGroup();
            ToggleGroup group5 = new ToggleGroup();
            ToggleGroup group6 = new ToggleGroup();
            ToggleGroup group7 = new ToggleGroup();
            ToggleGroup group8 = new ToggleGroup();
            
            UserLogin.setToggleGroup(group1);
            NoUserLogin.setToggleGroup(group1);
            
            ImsEnabled.setToggleGroup(group2);
            ImsDisabled.setToggleGroup(group2);
            
            VaccTorr.setToggleGroup(group3);
            VaccKpa.setToggleGroup(group3);
            
            LoadEnabled.setToggleGroup(group4);
            LoadDisabled.setToggleGroup(group4);
            
            LoadRemEnabled.setToggleGroup(group5);
            LoadRemDisabled.setToggleGroup(group5);
            
            NotepadEnabled.setToggleGroup(group6);
            NotepadDisabled.setToggleGroup(group6);
            
            AutoSendEnabled.setToggleGroup(group7);
            AutoSendDisabled.setToggleGroup(group7);
            
            BINotifyEnabled.setToggleGroup(group8);
            BINotifyDisabled.setToggleGroup(group8);
            
            
           Timeline timeline;
           timeline = new Timeline(
           new KeyFrame(Duration.seconds(0),
           new EventHandler<javafx.event.ActionEvent>() {
           @Override
           public void handle(javafx.event.ActionEvent event) {
                 Time.setText(gettime());
                 Date.setText(getdate());
                }}
              ),
            new KeyFrame(Duration.seconds(1))
          );
    timeline.setCycleCount(Animation.INDEFINITE);
    timeline.play();
            
    ProgressBar.setProgress(0.1F);       
    }    
    
    
     public String getdate()          
  {
    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    Date date = new Date();
    System.out.println(dateFormat.format(date)); 
    return dateFormat.format(date);
  }
  public String gettime()          
  {
    DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss a");
    Date date = new Date();
    System.out.println(dateFormat.format(date));
    
    return dateFormat.format(date);
  }

    @FXML
    private void BI_Bypass_Clicked(MouseEvent event) {
        System.out.println(event);
    }

    @FXML
    private void Plus_Clicked(MouseEvent event) {
        System.out.println(event);
        
        final int value = (int)((ProgressBar.getProgress())/0.20F );
        byte incr = (byte) value;
        
        if (incr >= 0 && incr < 6 && ProgressBar != null) {
	incr++;
        
	if (incr == 6) {
            ProgressBar.setProgress(1F);
            } else {
                ProgressBar.setProgress(incr * 0.20F);
        
            }
        }
    }

    @FXML
    private void Minus_Clicked(MouseEvent event) {
        System.out.println(event);
        
        final int value = (int)((ProgressBar.getProgress())/0.20F);
        byte decr = (byte) value;
        
        if (decr > 0 && decr <= 6 && ProgressBar != null) {
		decr--;
                
		if (decr == 6) {
			ProgressBar.setProgress(80);
		} else {
			ProgressBar.setProgress(decr * 0.20F);
		}
        }
    }

    @FXML
    private void Sterlized_Settings_Clicked(MouseEvent event) {
        System.out.println(event);
    }

    @FXML
    private void Printer_Settings_Clicked(MouseEvent event) {
        System.out.println(event);
    }

    @FXML
    private void Transfer_Settings_Clicked(MouseEvent event) {
        System.out.println(event);
    }

    @FXML
    private void Done_Clicked(MouseEvent event) {
        System.out.println(event);
    }

    @FXML
    private void Cancle_Clicked(MouseEvent event) {
        System.out.println(event);
    }

    @Override
    public void setParentScreen(STRStackPane screenPage) {
        myPage = screenPage;
        SceneHandler = myPage;
    }

    @Override
    public void initDisplay() {
        
    }

    @Override
    public void updateDisplayData() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
