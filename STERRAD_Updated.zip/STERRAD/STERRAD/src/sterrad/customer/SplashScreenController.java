/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sterrad.customer;

import BusinessLayer.SplashScreenModel;
import static BusinessLayer.UIEventID.*;
import static BusinessLayer.UIScreenID.SELECT_CYCLE_SCREEN;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import sterrad.ParentScreen;
import sterrad.STRStackPane;
import sterrad.UIBaseClass;

/**
 * FXML Controller class
 *
 * @author raja
 */
public class SplashScreenController extends UIBaseClass implements Initializable, ParentScreen {

    STRStackPane myPage;
    SplashScreenModel screenModelData;
    
    @FXML
    private Label lblPartNo;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        screenModelData = SplashScreenModel.getInstance();
    }    

    @Override
    public void setParentScreen(STRStackPane screenPage) {
         myPage = screenPage;
         SceneHandler = myPage;
        
    }

    @Override
    public void initDisplay() {
        lblPartNo.setText(screenModelData.getPartNo());
    }

    @Override
    public void updateDisplayData() {
     // myPage.setScreen(SELECT_CYCLE_SCREEN);
        
    }

        
    @FXML 
    public void handleMouseClick(MouseEvent event) throws IOException {
        System.out.println("mouse click detected! "+event.getSource());
        ProcessKeyEvent(SPLASH_SCREEN_MOUSE_CLICK);
                 
        updateDisplayData();
    }
    
}
