/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sterrad;



import java.util.Hashtable;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.layout.StackPane;

/**
 *
 * @author raja
 */

public class STRStackPane  extends StackPane {
    

    private Hashtable screensList = new Hashtable();
    private Hashtable controllerList = new Hashtable();  
    
    public STRStackPane() {
        super();

    }

         
    public boolean loadScreen(int screenID, String resource) {
        try {
            FXMLLoader myLoader = new FXMLLoader(getClass().getResource(resource));
            System.out.println(resource+"rajesh12");
            myLoader.setResources(ResourceBundle.getBundle("resources/langbundle/labelsBundle", new Locale("en", "US")));
            System.out.println(resource+"rajesh1");
            System.out.println(myLoader+"rajesh");
            Parent loadScreen = myLoader.load();
            System.out.println(((ParentScreen) myLoader.getController()));
            
            ParentScreen myScreenController = ((ParentScreen) myLoader.getController());
            myScreenController.setParentScreen(this);
            
            screensList.put(screenID, loadScreen);
            controllerList.put(screenID, myScreenController);
                    
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }


    public boolean setScreen(final int screenID)  {       
  
        Node screenToRemove;
        
         if(screensList.get(screenID) != null) {  
            
          
            ((ParentScreen)controllerList.get(screenID)).initDisplay();
                
            if(!getChildren().isEmpty()) { 
                
                getChildren().add(0, (Node)screensList.get(screenID));  

                screenToRemove = getChildren().get(1);
                getChildren().remove(1);                    
            }
            else {

                getChildren().add((Node)screensList.get(screenID));       
            }

             return true;
         }
         else {
            System.out.println("screen hasn't been loaded!!! \n");
           return false;
         }
    }

    
    public boolean unloadScreen(String name) {
        if (screensList.remove(name) == null) {
            System.out.println("Screen didn't exist");
            return false;
        } else {
            return true;
        }
    }
    
}